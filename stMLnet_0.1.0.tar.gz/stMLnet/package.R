rm(list = ls())
gc()
rstudioapi::restartSession()

library(devtools)
library(usethis)
library(roxygen2)

###########
## part0 ##
###########

## 测试数据

library(dplyr)
ex_databases <- readRDS('F:/finalVersion/rawdata/Databases.V3.new.rds')
git_bc <- readRDS('F:/finalVersion/rawdata/giotto_bc.rds')
ex_exprMat <- git_bc@norm_expr
ex_annoMat <- git_bc@cell_metadata[,1:2] %>% select(Barcode=cell_ID,Cluster=celltype)
ex_locaMat <- git_bc@spatial_locs[,1:2]
ex_ligs_of_inter <- readRDS('F:/finalVersion/rawdata/10X_bc_Ligs_up.rds')
ex_recs_of_inter <- readRDS('F:/finalVersion/rawdata/10X_bc_Recs_expr.rds')
ex_tgs_of_inter <- readRDS('F:/finalVersion/rawdata/10X_bc_ICGs.rds')
ex_inputs <- list(exprMat,annoMat,locaMat,ligs_of_inter,recs_of_inter,tgs_of_inter)
names(ex_inputs) <- c('exprMat','annoMat','locaMat','ligs_of_inter','recs_of_inter','tgs_of_inter')
usethis::use_data(ex_databases,ex_inputs,internal = FALSE)

library(dplyr)
files <- list.files('F:/finalVersion/Rpackage/stMLnet.1.0.0/runscMLnet/work_test-in-0502-0930-5/')
files <- files[-grep('TME',files)]
ex_mulnetlist = lapply(files, function(file){

  readRDS(paste0('F:/finalVersion/Rpackage/stMLnet.1.0.0/runscMLnet/work_test-in-0502-0930-5/',file,"/scMLnet.rds"))

})
names(ex_mulnetlist) = files
ex_mulnetlist = ex_mulnetlist[!unlist(lapply(ex_mulnetlist, function(mulnet){nrow(mulnet$LigRec)==0}))]
usethis::use_data(ex_mulnetlist,internal = FALSE)

library(dplyr)
ex_LRTG_allscore = readRDS('F:/finalVersion/Rpackage/stMLnet.1.0.0/runModel/work_test-in-20220502-1630-1/LRTG_allscore_TME_Malignant.rds')
usethis::use_data(ex_LRTG_allscore,internal = FALSE)

## 编写代码
# ctrl+shift+alt+R: 添加注释
# 更新NAMESPACE，生成Rd文档
document()

## 加载测试
## 加载包内对象、数据、函数
## 不出现在环境空间
load_all('F:/finalVersion/Rpackage/stMLnet.1.0.0/')
getCellPairMLnet
runMLnet
ex_databases$LigRec.DB
ex_inputs$exprMat[1:4,1:4]
ex_mulnetlist$Bcell_Macrophage

## 查看内置数据
data()
# Data sets in package ‘stMLnet.1.0.0’:
#
# ex_databases
# ex_inputs
# ex_mulnetlist

## ???
## 运行example
run_examples()

## ???
## 单元测试
# 创建./tests/testthat文件夹和./tests/testthat.R文件
test()

## Build package, cleaning up automatically on success.
check()

## Build source package
build()

## install source package
install()

###########
## part1 ##
###########

## 测试create_mulityayer_network.R
load_all()
library(Seurat)
library(dplyr)
resMLnet <- runMLnet(ExprMat = ex_inputs$exprMat, AnnoMat = ex_inputs$annoMat,
                     LigClus = 'Tcell', RecClus = 'Malignant', Normalize = F, NormMethod = "LogNormalize",
                     logfc.ct = 0.1, pct.ct = 0.05, pval.ct = 0.05, expr.ct = 0.1,
                     ProjectName = 'test-in-0502-0930-1', Databases = NULL,
                     TGList=ex_inputs$tgs_of_inter, LigList=ex_inputs$ligs_of_inter, RecList=ex_inputs$recs_of_inter)
resMLnet$details

resMLnet <- runMLnet(ExprMat = ex_inputs$exprMat, AnnoMat = ex_inputs$annoMat,
                     LigClus = c('Tcell','Endothelial'), RecClus = 'Malignant', Normalize = F, NormMethod = "LogNormalize",
                     logfc.ct = 0.1, pct.ct = 0.05, pval.ct = 0.05, expr.ct = 0.1,
                     ProjectName = 'test-in-0502-0930-2', Databases = NULL,
                     TGList=ex_inputs$tgs_of_inter, LigList=ex_inputs$ligs_of_inter, RecList=ex_inputs$recs_of_inter)
resMLnet$details

resMLnet <- runMLnet(ExprMat = ex_inputs$exprMat, AnnoMat = ex_inputs$annoMat,
                     LigClus = NULL, RecClus = 'Malignant', Normalize = F, NormMethod = "LogNormalize",
                     logfc.ct = 0.1, pct.ct = 0.05, pval.ct = 0.05, expr.ct = 0.1,
                     ProjectName = 'test-in-0502-0930-3', Databases = NULL,
                     TGList=ex_inputs$tgs_of_inter, LigList=ex_inputs$ligs_of_inter, RecList=ex_inputs$recs_of_inter)
resMLnet$details

resMLnet <- runMLnet(ExprMat = ex_inputs$exprMat, AnnoMat = ex_inputs$annoMat,
                     LigClus = NULL, RecClus = c('Malignant','Tcell'), Normalize = F, NormMethod = "LogNormalize",
                     logfc.ct = 0.1, pct.ct = 0.05, pval.ct = 0.05, expr.ct = 0.1,
                     ProjectName = 'test-in-0502-0930-4', Databases = NULL,
                     TGList=ex_inputs$tgs_of_inter, LigList=ex_inputs$ligs_of_inter, RecList=ex_inputs$recs_of_inter)
resMLnet$details

resMLnet <- runMLnet(ExprMat = ex_inputs$exprMat, AnnoMat = ex_inputs$annoMat,
                     LigClus = NULL, RecClus = NULL, Normalize = F, NormMethod = "LogNormalize",
                     logfc.ct = 0.1, pct.ct = 0.05, pval.ct = 0.05, expr.ct = 0.1,
                     ProjectName = 'test-in-0502-0930-5', Databases = NULL,
                     TGList=ex_inputs$tgs_of_inter, LigList=ex_inputs$ligs_of_inter, RecList=ex_inputs$recs_of_inter)
resMLnet$details

resMLnet <- runMLnet(ExprMat = ex_inputs$exprMat, AnnoMat = ex_inputs$annoMat,
                     LigClus = 'Endothelial', RecClus = 'Malignant', Normalize = T, NormMethod = "LogNormalize",
                     logfc.ct = 0.1, pct.ct = 0.05, pval.ct = 0.05, expr.ct = 0.1,
                     ProjectName = 'test-in-0502-0930-6', Databases = NULL,
                     TGList=ex_inputs$tgs_of_inter, LigList=ex_inputs$ligs_of_inter, RecList=ex_inputs$recs_of_inter)
resMLnet$details

resMLnet <- runMLnet(ExprMat = ex_inputs$exprMat, AnnoMat = ex_inputs$annoMat,
                     LigClus = NULL, RecClus = NULL, Normalize = T, NormMethod = "LogNormalize",
                     logfc.ct = 0.1, pct.ct = 0.05, pval.ct = 0.05, expr.ct = 0.1,
                     ProjectName = 'test-in-0502-0930-7', Databases = NULL,
                     TGList=ex_inputs$tgs_of_inter, LigList=NULL, RecList=NULL)
resMLnet$details

###########
## part2 ##
###########

## 测试calculateSignalActivity.R
load_all()
ex_mulnetlist$Bcell_Macrophage

library(Seurat)
library(SeuratWrappers)
library(dplyr)

DistMat <- as.matrix(dist(ex_inputs$locaMat))
colnames(DistMat) <- colnames(ex_inputs$exprMat)
rownames(DistMat) <- colnames(ex_inputs$exprMat)
exprMat.Impute <- suppressMessages(runImputation(exprMat = ex_inputs$exprMat))
clusters <- ex_inputs$annoMat$Cluster %>% unique() %>% as.character()

resSigActList <- list()
for (cluster in clusters) {

  resSigActList[[cluster]] <- getSiganlActivity(ExprMat = exprMat.Impute,
                                 DistMat = DistMat,
                                 AnnoMat = ex_inputs$annoMat,
                                 MulNetList = ex_mulnetlist,
                                 Receiver = cluster, Sender = NULL,
                                 Group = NULL, far.ct = 0.75, close.ct = 0.25,
                                 Downsample = FALSE, ProjectName = 'test-in-20220502-1630-1')

}
str(resSigActList,max.level = 2)
resSigActList$Malignant$TME_Malignant$LRs_score$ABHD2[1:4,1:4]
resSigActList$Malignant$TME_Malignant$TGs_expr$ABHD2[1:4]

for (cluster in clusters) {

  Sender <- clusters[clusters!=cluster]
  resSigActList[[cluster]] <- getSiganlActivity(ExprMat = exprMat.Impute,
                                                DistMat = DistMat,
                                                AnnoMat = ex_inputs$annoMat,
                                                MulNetList = ex_mulnetlist,
                                                Receiver = cluster, Sender = Sender,
                                                Group = NULL, far.ct = 0.75, close.ct = 0.25,
                                                Downsample = FALSE, ProjectName = 'test-in-20220502-1630-2')

}
str(resSigActList,max.level = 2)
resSigActList$Malignant$Endothelial_Malignant$LRs_score$ABHD2[1:4,1:4]
resSigActList$Malignant$Endothelial_Malignant$TGs_expr$ABHD2[1:4]

# modify in 20220511
# 将runImputation移动到getSiganlActivity内部
for (cluster in clusters) {

  Sender <- clusters[clusters!=cluster]
  resSigActList[[cluster]] <- getSiganlActivity(ExprMat = ex_inputs$exprMat,
                                                DistMat = DistMat,
                                                AnnoMat = ex_inputs$annoMat,
                                                MulNetList = ex_mulnetlist,
                                                Receiver = cluster, Sender = Sender,
                                                Group = NULL, far.ct = 0.75, close.ct = 0.25,
                                                Downsample = FALSE, ProjectName = 'test-in-20220511-2030-1')

}
str(resSigActList,max.level = 2)
resSigActList$Malignant$Endothelial_Malignant$LRs_score$ABHD2[1:4,1:4]
resSigActList$Malignant$Endothelial_Malignant$TGs_expr$ABHD2[1:4]

###########
## part3 ##
###########

load_all()

library(doParallel)
library(parallel)
library(Metrics)
library(doSNOW)
library(dplyr)
library(ranger)
library(caret)

# 并行计算需要加载函数和数据到当前环境
data("ex_LRTG_allscore")
source('./R/calculate_signal_importance.R')

## test example targets by hand (TME-Malignant)

t1 <- Sys.time()
rfModelList <- lapply(1:6, function(i){

  trainx = ex_LRTG_allscore$LRs_score[[i]]
  trainy = ex_LRTG_allscore$TGs_expr[[i]]
  runRFModel(trainx = trainx, trainy = trainy, auto_para = TRUE,
             n.trees = 500, n.trys = 10, tree.method = 'variance',
             node.size = 5,  nPert = 10)

})
names(rfModelList) <- names(ex_LRTG_allscore$LRs_score)[1:6]
t2 <- Sys.time()
message(paste0('Running times: ',paste(signif(t2-t1,4),units(signif(t2-t1,4)),sep = ' ')))
# Running times: 8.686 mins

t1 <- Sys.time()
cl <- makeSOCKcluster(6)
registerDoSNOW(cl)
n.TG <- 6
pb <- txtProgressBar(min=0, max=n.TG, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)
rfModelList_2 <- foreach(i=1:n.TG, .packages=c("dplyr","ranger",'Metrics','caret'),
                       .options.snow=opts, .errorhandling = "stop"
) %dopar% {
  message(paste0("\ngene",i,'\n'))
  trainx = ex_LRTG_allscore$LRs_score[[i]]
  trainy = ex_LRTG_allscore$TGs_expr[[i]]
  runRFModel(trainx = trainx, trainy = trainy, auto_para = TRUE,
             n.trees = 500, n.trys = 10,tree.method = 'variance',
             node.size = 5,  nPert = 10)
}
names(rfModelList) <- names(ex_LRTG_allscore$LRs_score)[1:6]
close(pb)
stopCluster(cl)
gc()
t2 <- Sys.time()
message(paste0('Running times: ',paste(signif(t2-t1,4),units(signif(t2-t1,4)),sep = ' ')))
# Running times: 5.231 mins

resSigImport <- mergeVarsImport(rfModelList = rfModelList,
                                label = 'TME-Malignant',
                                projectName = 'test-in-20220503-1440-1')

## test multiple targets by hand (TME-Malignant)

t1 <- Sys.time()
n.TG <- length(ex_LRTG_allscore$LRs_score)
cl <- makeSOCKcluster(6)
registerDoSNOW(cl)
pb <- txtProgressBar(min=0, max=n.TG, style=3)
progress <- function(n) setTxtProgressBar(pb, n)
opts <- list(progress=progress)
rfModelList_2 <- foreach(i=1:n.TG, .packages=c("dplyr","ranger",'Metrics','caret'),
                         .options.snow=opts, .errorhandling = "stop"
) %dopar% {
  message(paste0("\ngene",i,'\n'))
  trainx = ex_LRTG_allscore$LRs_score[[i]]
  trainy = ex_LRTG_allscore$TGs_expr[[i]]
  runRFModel(trainx = trainx, trainy = trainy, auto_para = TRUE,
             n.trees = 500, n.trys = 10,tree.method = 'variance',
             node.size = 5,  nPert = 10)
}
names(rfModelList_2) <- names(ex_LRTG_allscore$LRs_score)
close(pb)
stopCluster(cl)
gc()

resSigImport <- mergeVarsImport(rfModelList = rfModelList_2,
                                label = 'TME-Malignant',
                                projectName = 'test-in-20220503-1440-2')

t2 <- Sys.time()
message(paste0('Running times: ',paste(signif(t2-t1,4),units(signif(t2-t1,4)),sep = ' ')))
# Running times: 1.184 hours

## test multiple targets by hand (Sender-Receiver)

time_ls <- c()
files <- list.files('./runModel/work_test-in-20220502-1630-2/')
for (file in files) {

  label <- paste(unlist(strsplit(file,'[_.]'))[3:4],collapse = '-')
  message(paste0('running jobs: ',label))

  LRTG_allscore <- readRDS(paste0('./runModel/work_test-in-20220502-1630-2/',file))
  n.TG <- length(LRTG_allscore$LRs_score)

  if(n.TG>0){

    t1 <- Sys.time()
    cl <- makeSOCKcluster(6)
    registerDoSNOW(cl)
    pb <- txtProgressBar(min=0, max=n.TG, style=3)
    progress <- function(n) setTxtProgressBar(pb, n)
    opts <- list(progress=progress)
    rfModelList <- foreach(i=1:n.TG, .packages=c("dplyr","ranger",'Metrics','caret'),
                           .options.snow=opts, .errorhandling = "stop"
    ) %dopar% {
      message(paste0("\ngene",i,'\n'))
      trainx = LRTG_allscore$LRs_score[[i]]
      trainy = LRTG_allscore$TGs_expr[[i]]
      runRFModel(trainx = trainx, trainy = trainy, auto_para = TRUE,
                 n.trees = 500, n.trys = 10,tree.method = 'variance',
                 node.size = 5,  nPert = 10)
    }
    names(rfModelList) <- names(LRTG_allscore$LRs_score)
    close(pb)
    stopCluster(cl)
    gc()

    resSigImport <- mergeVarsImport(rfModelList = rfModelList,
                                    label = label,
                                    projectName = 'test-in-20220503-1440-3')

    t2 <- Sys.time()
    message(paste0('Running times: ',paste(signif(t2-t1,4),units(signif(t2-t1,4)),sep = ' ')))
    time_ls <- c(time_ls,paste(signif(t2-t1,4),units(signif(t2-t1,4)),sep = ' '))

  }

}



###########
## part4 ##
###########

load_all()

## color

library(ggsci)
celltype <- c("Malignant","Macrophage","Stroma","Bcell","Endothelial","Epithelial","Tcell")
myColor <- PrepareColorDB(CellTypes = celltype)

## NetworkPlot

library(igraph)
library(plotrix)
InputDir <- './getPIM/work_test-in-20220503-1440-3/'
Metrics <- c('n_LRs','n_TGs','IM','IM_norm','mean_IM','mean_IM_norm')
ColorDB <- myColor$Celltypes
lapply(Metrics, function(Metric){
  DrawNetworkPlot(InputDir = InputDir, Metric = Metric, ColorDB = ColorDB, gtitle = 'CCI')
})

## MLnetPlot

library(dplyr)
library(ggraph)

MLnetDir <- './runscMLnet/work_test-in-0502-0930-5/Tcell_Malignant/scMLnet.rds'
ImportDir <- './getPIM/work_test-in-20220503-1440-3/LRTG_im_clean_Tcell-Malignant.rds'

DrawMLnetPlot(MLnetDir = MLnetDir, ImportDir = ImportDir, Signal = 'SEMA4D',
              Check = TRUE, top.n = 10, ColorDB = myColor$Keys)

DrawMLnetPlot(MLnetDir = MLnetDir, ImportDir = ImportDir, Signal = 'TGFB1',
              Check = TRUE, top.n = 10, ColorDB = myColor$Keys)

## EdgeBundlingPlot

library(dplyr)
library(ggraph)

InputDir <- './runModel/work_test-in-20220502-1630-2/'
colordb <- unlist(myColor)
names(colordb) <- gsub('.*\\.','',names(colordb))
for (Cluster in celltype) {

  gtitle <- paste0('sender_',Cluster)
  DrawEdgeBundlingPlot(InputDir = InputDir, Cluster = Cluster, ColorDB = colordb,
                       Check = TRUE, top.n = 50, gtitle = gtitle, p_height = 7.5, p_width = 7)

}

## AlluviumPlot

library(ggalluvial)

InputDir <- './getPIM/work_test-in-20220503-1440-3/'
colordb <- unlist(myColor)
names(colordb) <- gsub('.*\\.','',names(colordb))
for (Cluster in celltype) {

  gtitle <- paste0('sender_',Cluster)
  DrawAlluviumPlot(InputDir = InputDir, Cluster = Cluster, ColorDB = colordb,
                   Check = TRUE, top.n = 30, gtitle = gtitle, p_height = 7.5, p_width = 7)

}

## EnrichmentPlot

library(org.Hs.eg.db)
library(clusterProfiler)
library(enrichplot)

InputDir <- './runscMLnet/work_test-in-0502-0930-5/'
for (Cluster in celltype) {

  gtitle <- paste0('sender_',Cluster)
  DrawEnrichmentPlot(InputDir = InputDir, Cluster = Cluster, top.n = 3, gtitle = gtitle, p_height = 7.5, p_width = 7)

}

InputDir <- './runscMLnet/work_test-in-0502-0930-5/'
for (Cluster in celltype) {

  print(Cluster)
  gtitle <- paste0('sender_',Cluster)
  tryCatch({
    DrawEnrichmentPlot(InputDir = InputDir, Cluster = Cluster, top.n = 3, gtitle = gtitle, p_height = 11.5, p_width = 10.5)
  }, error = function(e){
    message(paste0('Error in ',gtitle))
  })

}
